// 비밀번호 찾기 버튼 클릭
$('.searchPwd_btn').click(function(){
   location.href='/dangjang/shop/member/find/pwd';
});

// 로그인 버튼 클릭
$('.resultIdSection .btn_login').click(function(){
   location.href="/dangjang/shop/member/login";
});
