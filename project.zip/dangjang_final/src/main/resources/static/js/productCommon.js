function productDetail (seq_product){
    console.log("제품 상세 보기");
    location.href='/dangjang/shop/product?num='+seq_product;
}